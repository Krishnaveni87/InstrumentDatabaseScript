﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DataTableExample.Model
{
    public class AreaModel
    {
        public List<SelectListItem> Areas { get; set; }

        public string Area { get; set; }

        public int Areaid { get; set; }
    }
}